<nav class="navtop">
    <div>
        <h1><a href="patients.php">CRUD matrix</a></h1>
        <a href="logout.php" onClick="return confirm('Are you sue you want to logout?');"><i class="fas fa-sign-out-alt"></i>Logout</a>
    </div>
</nav>