CRUD matrix for patient listing in corephp & ajax

Note:
    DB file 'corePhp.sql' included with dummy records

    to update db credentials please use 'config.php' file